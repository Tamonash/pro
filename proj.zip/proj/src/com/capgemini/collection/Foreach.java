package com.capgemini.collection;

import java.util.ArrayList;

public class Foreach {

/*static void printArray(int intArr[]) {
for(int arrayindex: intArr)
System.out.println(arrayindex);
}
*/
	
	
/*static public void printCollection(ArrayList arrList) {
for(Object object: arrList)
System.out.println(object);

}*/
}


